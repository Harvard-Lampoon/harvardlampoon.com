
        <?php get_template_part('amp/partials/footer'); ?>

        <div class="clear"></div>
    </div>
    <!-- end: #wrapper --> 

    <?php get_template_part('partials/svg-icons'); ?>

    <?php wp_footer(); ?>

    </body>
</html>
