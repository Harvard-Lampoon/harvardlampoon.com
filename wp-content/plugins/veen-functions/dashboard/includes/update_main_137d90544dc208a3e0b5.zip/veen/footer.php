
        <?php get_template_part('partials/footer'); ?>

        <div class="clear"></div>
    </div>
    <!-- end: #wrapper --> 

    <!-- W3TC-include-css -->
    <!-- W3TC-include-js-head -->

    <?php get_template_part('partials/svg-icons'); ?>

    <?php wp_footer(); ?>      
    </body>
</html>
